/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan7;

import java.util.Scanner;

/**
 *
 * @author M S I
 */
public class KualitasMangga {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int ulang = 1, banyak, jumlah, berat;
        int biasa = 0, bagus = 0, unggul = 0;

        System.out.println("Menentukan jumlah kulitas setiap mangga");
        System.out.print("Banyak manggga yang diproses  :");
        banyak = sc.nextInt();
        do {
            System.out.print("Masukan berat " + ulang + " :");
            berat = sc.nextInt();
            ulang++;
            if (berat <= 0) {
                ulang--;
            } else if (berat < 500) {
                biasa++;
            } else if (500 <= berat && berat < 750) {
                bagus++;
            } else if (berat >= 750) {
                unggul++;
            }
        } while (ulang <= banyak);
        
        
        System.out.println("");
        System.out.println("Dari " + banyak + " yang di timbang");
        System.out.println("Biasa :" + biasa);
        System.out.println("Bagus :" + bagus);
        System.out.println("Unggul :" + unggul);
    }

}
