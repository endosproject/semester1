/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan7;

import java.util.Scanner;

/**
 *
 * @author M S I
 */
public class nilaiFinal {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double uts1, uts2, uas;
        double nilaifinal;

        System.out.println("Menentukan nilai final");
        System.out.print("masukan nilai uts 1 :");
            uts1 = sc.nextInt();
            System.out.print("masukan nilai uts 2 :");
            uts2 = sc.nextInt();
            System.out.print("masukan nilai uas   :");
            uas = sc.nextInt();

        do {
            System.out.println(" MASUKAN NILAI DENGAN BENAR  ");
            System.out.print("masukan nilai uts 1 :");
            uts1 = sc.nextInt();
            System.out.print("masukan nilai uts 2 :");
            uts2 = sc.nextInt();
            System.out.print("masukan nilai uas   :");
            uas = sc.nextInt();

            if (uts1 < 0 || uts1 > 100 || uts2 < 0 || uts2 > 100 || uas < 0 || uas > 100) {
                
            }
        } while (uts1 < 0 || uts1 > 100 || uts2 < 0 || uts2 > 100 || uas < 0 || uas > 100);
        nilaifinal = (0.3 * uts1) + (0.3 * uts2) + (0.4 * uas);
        if (nilaifinal >= 80) {
            System.out.println("Grade A");
        }
        if ((nilaifinal > 65) && (nilaifinal < 80)) {
            System.out.println("Grade B");
        }
        if ((nilaifinal >= 55) && (nilaifinal < 65)) {
            System.out.println("Grads C");
        }
        if ((nilaifinal >= 50) && (nilaifinal < 55)) {
            System.out.println("Grade D");
        }
        if ((nilaifinal < 50)) {
            System.out.println("Grade e");
        }

    }

}
