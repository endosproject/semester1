
package pertemuan7;

import java.util.Scanner;

public class p {

    public static void main(String[] args) {
        Scanner tombol = new Scanner(System.in);
        int N,j=7;
        while (true) { // seolah berputar tanpa henti
            System.out.print("Masukkan banyak data : ");
            N = tombol.nextInt();
            if (N > 0) {
                
                
                break;
            }
            System.out.print("Data yang Anda masukkan harus lebih besar dari nol ! ");
             j=j+N;
             System.out.println(j);
        }
    }

}
