package pertemuan7;

import java.util.Scanner;

public class Modifikasiprogram {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int banyak, data = 1, x;
        double jkuadrat = 0, jumlah = 0;
        int min = 0, maks = 0;
        double ratarata, variansi, deviriansi;
        boolean status = true;

        System.out.print("Masukan banyak data yang dikelola  :");
        banyak = sc.nextInt();

        do {
            System.out.print("Data ke " + data + "  :");
            x = sc.nextInt();
            jkuadrat = jkuadrat + Math.pow(x, 2);
            if (status == true) {
                maks = x;
                min = x;
                status = false;
            } else {
                if (x > maks) {
                    maks = x;
                }
                if (x < min) {
                    min = x;
                }
            }

            jumlah = jumlah + x;
            data++;
        } while (data <= banyak);

        ratarata = jumlah / banyak;
        variansi = (jkuadrat - (banyak + Math.pow(ratarata, 2))) / banyak;
        deviriansi = Math.sqrt(variansi);

        System.out.println("=================================");

        System.out.println("Data terbesar  :" + maks);
        System.out.println("Data terkecil  :" + min);
        System.out.println("Rentang        :" + (maks - min));
        System.out.println("Rata-rata      :" + ratarata);
        System.out.println("Variansi       :" + variansi);
        System.out.println("Deviasi Standart    :" + deviriansi);
    }
}
