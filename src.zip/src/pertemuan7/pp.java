/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pertemuan7;

/**
 *
 * @author M S I
 */
public class pp {

    public static void main(String[] args) {
        int bilangan = 1;
        do {
            System.out.println(bilangan);
            bilangan = bilangan + 1;
        } while (bilangan <= 10);

    }

}
