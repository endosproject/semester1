package pertemuan7;//merupakan tempat membuat program seperti halnya folder


import java.util.Scanner;//menginput scanner ke program atau memasukan metoode-metode 
//yang berada di atas deklarasi class scanner System.in dan System.out 
//agar dapat terpakai dan terbaca dalam program

public class segitiga {//memanggil method main atau merupakan nama class dari program yang dijalankan.Disini nama classnya segitiga

    public static void main(String[] args) {//memanggil  method main atau fungsi main diama public  pada bagian ini 
        //menandakan  bahwa objek,method,atau atribut dapat diakses dari class ini.
        Scanner sc = new Scanner(System.in);//membentuk objek baru dan objek bernama sc.Untuk memeberi perintah 
        //menginputkan data didalam program,supaya user dapat memasukan nilai data sendiri kedalam program.
        int a, b, c;//mendeklarasikan variabel a,b,c dengan tipe data integer
        double D, x1, x2;//mendeklarasikan variabel D,x1,x2 kedalalm tipe data double
        do {
            System.out.print("masukan nilai a: ");//Mencetak perintah "masukan nilai a"
            a = sc.nextInt();//menerima inputan dari user kedalam variabel a dengan tipe data integer
            if (a == 0) {//Jika a==0 maka program akan berjalan dengan bernilai benar.
                //maka program akan melakukan operasi berikutnya.
                System.out.println("nilai a tidak boleh 0");//mencetak dan menampilkan "nilai a tidak boleh sama dengan 0

            }
        } while (a == 0);//selama variabel a sama dengan 0 maka perulangan akan terus berjalan
        System.out.print("masukan nilai b :");//mencetak dan menampilkan perintah "masukan nilai b"
        b = sc.nextInt();//menerima inputan user kedalam variabel b dengan tipe data integer
        System.out.print("masukan nilai c :");//mencetak dan menampilkan "masukan nilai c"
        c = sc.nextInt();//menerima inputan user kedalam variabelc dengan tipe data integer

        D = b * b - (4 * a * c);//perintah operasi hitung yang hasilnya akan dimasukan ke variabel D,dan akan digunakan dipercabangan if else
        if (D < 0 || a == 0) {//jika (D < 0 || a == 0) maka program akan berjalan dengan bernilai benar.Maka program akan melakukan operasi berikut
            System.out.println("tidak mempunyai akar nyata atau real");//mencetak dan menampilkan "tidak mempunyai akar nyata atau real"
        } else if (D == 0) {//jika maka (D == 0) maka program akan berjalan dengan bernilai benar,sehingga kondisi lainya tidak diperiksa.
                                      // Maka program akan melakukan operasi berikutnya
            x1 = -b / (2 * a);//operasi perhitungan yang hasilnya akan di masukan ke variabel x1
            System.out.println("akar tunggal yakni :" + x1);//mencetak dan menampilkan hasil operasi perhitungan variabel x1
        } else {//program akan berjalan jika kedua pernyatan diatas tidak benar atau salah.
            x1 = (-b + Math.sqrt(D) / (2 * a));//operasi perhitungan yang hasilnya akan dimasukan ke variabel x1
            x2 = (-b - Math.sqrt(D) / (2 * a));//operasi perhitungan yang hasilnya akan dimasukan ke variabel x2
            System.out.println("akar pertama :" + x1);//mencetak dan menampilkan hasil perhitungan variabel x1
            System.out.println("akar kedua :" + x2);//mencetak danmenampilkan hasil perhitungan variabel x2
        }

    }

}
