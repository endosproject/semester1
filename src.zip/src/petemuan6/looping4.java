/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petemuan6;

/**
 *
 * @author M S I
 */
import java.util.Scanner;

public class looping4 {

    public static void main(String[] args) {
        int ulang = 1;
        double jumlah = 0;
        double bilangan;
        Scanner tombol = new Scanner(System.in);
        do {

            System.out.print("Masukkan data ke " + ulang + " : ");

            bilangan = tombol.nextDouble();
            jumlah = jumlah + bilangan;
            ulang++;
        } while (ulang <= 5);
        System.out.println(" Jumlah 5 bilangan tersebut adalah " + jumlah);

    }

}
