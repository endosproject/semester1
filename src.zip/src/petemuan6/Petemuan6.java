package petemuan6;//merupakan tempat  membuat program seperti halnya folder
import java.util.Scanner;//menginput scanner ke program atau untuk memasukan metode-metode yang berada diatas 
//deklarasi class scanner yaitu system.in dan system.outagar dapat dipakai dan tebaca dalam program.
public class Petemuan6 {//Memanggil method main atau merupakan-nama class dari program yang dijalankkan.Disini clasnya pertemuan6
    public static void main(String[] args) {//Memanggil method main atau fungsi main dimana public pada bagian ini
        //menandakan bahwa objek,method,atau atribut dapat diaksesdari class ini.
        Scanner sc = new Scanner(System.in);//membentuk objek baru dan objek bernama sc.Untuk memeberi perintah 
        //menginputkan data didalam program,supaya user dapat memasukan nilai data sendiri kedalam program.
        int celcius;//mendeklarasikan variabel celcius kedalam tipe data integer 
        double reamur, fahrenheit;//mendeklarasikan variabel reamur,fahrenheit kedalam tipe data double
        int banyak, ulang = 1;//deklarasi variabel
        System.out.print("Masukan banyak  :");//mencetak perintah masukan banyak
        banyak = sc.nextInt();//menrima inputan data dari user kedalam variabe banyak dengan tipe data integer

        while (ulang <= banyak) {//selama nilai variabel ulang lebih kecil dari nilai 
                //variabel banyak maka perulangan akan berjalan terus 
            System.out.print("Masukan suhu celcius ke " + ulang + "  :");////Untuk mencetak masukan suhu celcius 
            //ke nilai dari variabel ulang.
            //Nilai dari variabel ulang yaitu nilai yang diinput oleh user untuk diproses dalam opersi hitung berikutnya.
            //"+ulang+" artinya perulangan nilai data dari satu sampai batas yang ditentukanyaitu nilai variabel banyak.
            celcius = sc.nextInt();//menerima inputan data dari user kedalam variabel celcius dengan tipe data integer
            reamur = 0.8 * celcius;//rumus mencari reamur atau operassi hitung perkalian yang hasilnya akan dimasukan ke variabel reamur
            System.out.println("Konversi reamur :" + reamur);//mencetak hasil perhitungan variabel reamur
            fahrenheit = 1.8 * celcius + 32;//rumus mencari fahrenheit atau operassi hitung perkalian dan penjumlahan
            //yang hasilnya akan dimasukan ke variabel fahrenheit
            System.out.println("Konversi fahrenhrit  :" + fahrenheit + "\n");//mencetak hasil perhitungan variabel fahrenheit
            ulang++;//perintah increment untuk mennaikan nilai variabel ulang sampai batas yang ditentukan oleh variabel banyak yang  diinput oleh user.
        }

    }

}

