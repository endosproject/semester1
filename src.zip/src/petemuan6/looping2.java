/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petemuan6;

/**
 *
 * @author M S I
 */
public class looping2 {

    public static void main(String[] args) {
        int bilangan = 1;
        do {

            System.out.print(bilangan + ",");
            bilangan = bilangan + 1;
        } while (bilangan < 21);
    }

}
