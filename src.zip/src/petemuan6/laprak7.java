/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petemuan6;

/**
 *
 * @author M S I
 */
public class laprak7 {

    public static void main(String[] args) {
        int bilangan = 0;
        do {
            bilangan=bilangan+1;

            System.out.println(bilangan);
            
        } while (bilangan <=10);

    }

}
