/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package petemuan6;

/**
 *
 * @author M S I
 */
public class Looping3 {

    public static void main(String[] args) {
        int jumlah = 1, bilangan = 1;
         do{
             System.out.println("Jumlah dari 5+10+…+100 = " + jumlah);
            jumlah = jumlah + bilangan;
            bilangan = bilangan + 5;
            
        }while (bilangan <= 100);
         
        
    }

}
