package petemuan6;//merupakan tempat  membuat program seperti halnya folder

public class Bensin {//Memanggil method main atau merupakan-nama class dari program yang dijalankkan.Disini clasnyaBensin

    public static void main(String[] args) {//Memanggil method main atau fungsi main dimana public pada bagian ini
        //menandakan bahwa objek,method,atau atribut dapat diaksesdari class ini.

        int liter = 1, harga = 6500;////memanggil variabel nilai liter yaitu ulang=1,memanggil variabel nilai harga yaitu jumlah=0
        //dan mendeklarasikan variabel liter,harga kedalam tipe integer
        System.out.println("Harga perliter Rp 6500");////membuuat baris code untuk mencetak dan menampilkan Harga perliter Rp 6500

        System.out.println("Jumlah liter\tHarga(Rp)");//membuat baris code untuk mencetak dan menampilakan Jumlah liter,Harga(Rp)
        // (\t) artinyya tab,memberikan jarak yang diinginkan user
        
        while (liter <= 20) {//selama variabel liter kurang dari sama dengan 20 maka perulangan akan terus berjalan
            System.out.print(+liter + "\t\t");////Untuk mencetak nilai dari variabel liter.Disini akan mencetak nilai lliter yaitu 1
            //sebelum nanti nilai variabel dinaikan pada perintah increment.// (\t) artinyya tab,memberikan jarak yang diinginkan user
            liter++;//perinttah increment untuk menaikan nilai variabel liter sampai batas yang ditentukan oleh perulangan yaitu 20.
            System.out.println(harga);//mencetak dan menampilkan nilai operasi hitung variabel harga
            harga = liter * 6500;//menghitung rumus harga atau operasi perhitungan perkalian yang hasilnya akan dimasukan ke variabel liter

        }
    }

}
