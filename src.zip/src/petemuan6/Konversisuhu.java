package petemuan6;//merupakan tempat  membuat program seperti halnya folder

import java.util.Scanner;//menginput scanner ke program atau untuk memasukan metode-metode yang berada diatas 
//deklarasi class scanner yaitu system.in dan system.outagar dapat dipakai dan tebaca dalam program.
public class Konversisuhu {//Memanggil method main atau merupakan-nama class dari program yang dijalankkan.Disini clasnya Konversi suhu
    public static void main(String[] args) {//Memanggil method main atau fungsi main dimana public pada bagian ini
        //menandakan bahwa objek,method,atau atribut dapat diaksesdari class ini.
        Scanner sc = new Scanner(System.in);//membentuk objek baru dan objek bernama sc.Untuk memeberi perintah 
        //menginputkan data didalam program,supaya user dapat memasukan nilai data sendiri kedalam program.
        int max, min, kenaikan;//mendeklarasikan variabel max,min,kenaikan kedalam tipe data integer.
        double f, r;//mendeklarasikan variabelf,r kedalam tipe data double.
        System.out.println("Tabel Konversi Celcius ke Reamuhr dan Fahrenheit");//membuuat baris code untuk mencetak dan menampilkan 
        //Tabel Konversi Celcius ke Reamuhr dan Fahrenheit
        System.out.print("Masukkan nilai suhu minimum  :");//mencetak perintah memasukan nilai suhu minimum
        min = sc.nextInt();//menerima inputan data dari usser kedalam variabel min dengan tipe data integer
        System.out.print("Masukkan selisih kenaikan    :");//mencetak perintah masukan selisih kenaikan
        kenaikan = sc.nextInt();//menerima inputan data dari user kedalam variabel kenaikan dengan tipe data integer
        System.out.print("Masukkan nilai suhu maksimum :");//mencetak perintah memasukan nilai suhu maksimum
        max = sc.nextInt();//menerima inputan dari user kedalam variabelmax dengan tipe data integer

        System.out.println("celcius\t\t reamur\t\t fahrenheit");//membuat baris code untuk mencetak dan menampilakan 
        //celcius reamur fahrenheiit // (\t) artinyya tab,memberikan jarak yang diinginkan user
        while (min <= max) {//selama variabel min kurang dari sama dengan variabel max maka perulangan akan terus berjalan

            r = 4 * min / 5;//rumus untuk mencari r atau operasi perkalian dan pembagian yang hasilnya akan di masukan kedalam variabel r

            f = min * 9 / 5 + 32;//rumus untuk mencari f atau operasi perkalian,pembagian,dan
            //penjumlahan yang hasilnya akan di masukan kedalam variabel f

            System.out.println(min + " \t\t " + r + " \t\t " + f);//mencetak dan menampilkan nilai hasil dari operasi 
            //hitunng variabel min/celcius,r,f // (\t) artinyya tab,memberikan jarak yang diinginkan user
            min = min + kenaikan;//perintah untuk menaikan nilai data min/celcius.

        }

    }

}
