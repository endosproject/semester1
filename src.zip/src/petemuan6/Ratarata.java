package petemuan6;//merupakan tempat  membuat program seperti halnya folder

import java.util.Scanner;//menginput scanner ke program atau untuk memasukan metode-metode yang berada diatas 
//deklarasi class scanner yaitu system.in dan system.outagar dapat dipakai dan tebaca dalam program.

public class Ratarata {//Memanggil method main atau merupakan-nama class dari program yang dijalankkan.Disini clasnya Ratarata.

    public static void main(String[] args) {//Memanggil method main atau fungsi main dimana public pada bagian ini
        //menandakan bahwa objek,method,atau atribut dapat diaksesdari class ini.
        Scanner sc = new Scanner(System.in);//membentuk objek baru dan objek bernama sc.Untuk memeberi perintah 
        //menginputkan data didalam program,supaya user dapat memasukan nilai data sendiri kedalam program.
        int banyak, ratarata, bilangan;//mendeklarasikan variabel banyak,ratarata,bilangan kedalam tipe data integer
        int ulang = 1, jumlah = 0;//memanggil variabel nilai ulang yaitu ulang=1,memanggil variabel nilai jumlah yaitu jumlah=0
        //dan mendeklarasikan variabel ulang,jumlah kedalam tipe integer
        System.out.print("Banyak data yang akan diprose  :");//mencetak perintah banyak data yang diproses
        banyak = sc.nextInt();//menerima inputan data dari user kedalam variabel banyak dengan tipe data integer
        while (ulang <= banyak) {//selama variabel ulang kurang dari sama dengan variabel banyak maka perulangan akan terus berjalan
            System.out.print("masukan data ke " + ulang + " :");//Untuk mencetak masukan data ke nilai dari variabel ulang.
            //Nilai dari variabel ulang yaitu nilai yang diinput oleh user untuk diproses dalam opersi hitung berikutnya.
            //"+ulang+" artinya perulangan nilai data dari satu sampai batas yang ditentukanyaitu nilai variabel banyak.
            bilangan = sc.nextInt();//menerima inputan data dari user ke dalam variabel bilangan dengan tipe data integer.
            jumlah = jumlah + bilangan;//perintah untuk menaikan nilai data variabel jumlah
            ulang++;//perintah increment untuk mennaikan nilai variabel ulang sampai batas 
                        //yang ditentukan oleh variabel banyak yang  diinput oleh user.

        }
        ratarata = jumlah / banyak;//rumus untuk mencari ratarata atau operasi hitung pembagian
        //yang hasilnya akan di masukan kedalam variabel ratarata
        System.out.println("Rata-rata data adalah " + ratarata);//mencetak dan menampilkan hasil nilai dari operasi perhitungan ratarata
    }

}
