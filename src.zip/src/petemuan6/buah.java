package petemuan6;//merupakan tempat  membuat program seperti halnya folder
import java.util.Scanner;//menginput scanner ke program atau untuk memasukan metode-metode yang berada diatas 
//deklarasi class scanner yaitu system.in dan system.outagar dapat dipakai dan tebaca dalam program.
public class buah {//Memanggil method main atau merupakan-nama class dari program yang dijalankkan.Disini clasnya buah
   public static void main(String[] args) {//Memanggil method main atau fungsi main dimana public pada bagian ini
        //menandakan bahwa objek,method,atau atribut dapat diaksesdari class ini.
        Scanner sc = new Scanner(System.in);//membentuk objek baru dan objek bernama sc.Untuk memeberi perintah 
        //menginputkan data didalam program,supaya user dapat memasukan nilai data sendiri kedalam program.
        int kecil = 0, besar = 0, sedang = 0, jumlah, banyak, ulang = 1, berat;
        System.out.print("Banyak mangga yang diproses :");//perintah mencetak banyak mangga
        banyak = sc.nextInt();//menerima inuputan data dari user kedalam variabel banyak dengan tipe data integer
        while (ulang <= banyak) {//selama nilai  variabel ulang lebih kecil dari nilai variabel banyak maka perulangan akan berjalan trus.
            System.out.print("berat mangga  " + ulang+" :");///Untuk mencetak berat mangga dan nilai dari variabel ulang.
            //Nilai dari variabel ulang yaitu nilai yang diinput oleh user untuk diproses dalam opersi hitung berikutnya.
            //"+ulang+" artinya perulangan nilai data dari satu sampai batas yang ditentukanyaitu nilai variabel banyak.
            berat = sc.nextInt();//menerima inputan data dari user kedalam variabel berat dengan tipe data integer
            ulang++;//perintah increment untuk mennaikan nilai variabel ulang sampai batas yang 
            //ditentukan oleh variabel banyak yang  diinput oleh user.
            if (berat < 200) {//jika nilai berat lebih kecil dari 200 maka akan diproses pada perintah increment kecil++.
                kecil++;////perintah increment untuk mennaikan nilai variabel kecil.
            }
            if (berat >= 200 && berat < 600) {//jika nilai berat lebih besar sama dengan 200 dan berat lebih kecil
                //dari 600 maka akan diproses pada perintah increment sedang++.
                sedang++;///perintah increment untuk mennaikan nilai variabel sedang.
            }
            if (berat >= 600) {//jika nilai berat lebih besar sama dengan 600 maka akan diproses pada perintah increment besar++.
                besar++;///perintah increment untuk mennaikan nilai variabel besar.
            }
        }
        System.out.println("Dari " + banyak + " mangga yang ditimbang");//mencetak nilai hasil (Dari +banyak+ mangga yang ditimbang).
                                 //+banyak+ nilai dari variabel banyak dengan tipe data integer yaitu 10
        System.out.println("Kecil :" + kecil+"  buah");//mencetak nilai hasil dari ("Kecil :" + kecil).
        System.out.println("Sedang :" + sedang+" buah");//mencetak nilai hasil dari ("Sedang :" + sedang).
        System.out.println("Besar  :" + besar+" buah");//mencetak nilai hasil dari ("Besar  :" + besar).
    }

}
